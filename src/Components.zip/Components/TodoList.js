// src/components/TodoList.js

import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchTodos , updateTodoAsync } from './todosSlice';
import './TodoList.css';
import EditModal from './EditModal';
import DetailView from './DetailView';
import EditIcon from '@material-ui/icons/Edit';
import VisibilityIcon from '@material-ui/icons/Visibility';
import DeleteIcon from '@material-ui/icons/Delete';

const TodoList = () => {
  const dispatch = useDispatch();
  const todos = useSelector((state) => state.todos.todos);
  const status = useSelector((state) => state.todos.status);
  const error = useSelector((state) => state.todos.error);

  useEffect(() => {
    if (status === 'idle') {
      dispatch(fetchTodos());
    }
  }, [status, dispatch]);

  const [editId, setEditId] = useState(null);
  const [viewId, setViewId] = useState(null);


  const handleCheckboxToggle = (id) => {
    console.log(`Checkbox toggled for todo with id ${id}`);
  };

 
  const handleEditClick = (id) => {
    setEditId(id);
  };

  const handleViewClick = (id) => {
    setViewId(id);
  };

  const handleEditClose = () => {
    setEditId(null);
  };

  const handleViewClose = () => {
    setViewId(null);
  };


  const handleEditSave = async (id, newTitle, newDescription) => {
    await dispatch(updateTodoAsync({ id, title: newTitle, description: newDescription }));
    setEditId(null);
  };

  if (status === 'loading') {
    return <div>Loading...</div>;
  }

  if (status === 'failed') {
    return <div>Error: {error}</div>;
  }

  return (
    <div className="todo-list-container">
    <ul className="todo-list">
      {todos.map((todo) => (
        <li key={todo.id} className="todo-item">
          <label
            htmlFor={`checkbox-${todo.id}`}
            className={todo.completed ? 'completed' : ''}
          >
            {todo.title}
          </label>
          <input
            type="checkbox"
            id={`checkbox-${todo.id}`}
            checked={todo.completed}
            onChange={() => handleCheckboxToggle(todo.id)}
          />
          <VisibilityIcon className="view-icon" onClick={() => handleViewClick(todo.id)} />
          <EditIcon
            className="edit-icon"
            onClick={() => handleEditClick(todo.id)}/>
          
            <DeleteIcon className="delete-icon" />
        </li>
      ))}
    </ul>
    {editId !== null && (
      <EditModal
        isOpen={true}
        onRequestClose={handleEditClose}
        onSave={handleEditSave}
        initialTitle={todos.find((todo) => todo.id === editId)?.title || ''}
          initialDescription={todos.find((todo) => todo.id === editId)?.description || ''}
          taskId={editId}
      />
    )}
     {viewId !== null && (
        <DetailView
          isOpen={true}
          onRequestClose={handleViewClose}
          todo={todos.find((todo) => todo.id === viewId) || {}}
        />
      )}
  </div>
  );
};

export default TodoList;
