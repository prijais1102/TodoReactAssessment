import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import  axios from 'axios'

export const fetchTodos = createAsyncThunk('todos/fetchTodos', async () => {
  const response = await fetch('http://localhost:3000/tasks');
  const data = await response.json();
  return data;
});

// export const updateTodoAsync = createAsyncThunk(
//   'todos/updateTodo',
//   async ({ id, title }) => {
//     const response = await axios.put(`http://localhost:3000/tasks/${id}`, {
//       title,
//     });
//     return response.data;
//   }
// );
export const updateTodoAsync = createAsyncThunk(
  'todos/updateTodo',
  async ({ id, title}) => {
    
      const existingTodo = await axios.get(`http://localhost:3000/tasks/${id}`);
      const updatedTodo = {
        ...existingTodo.data,
        title
      };

      const response = await axios.put(`http://localhost:3000/tasks/${id}`, updatedTodo);
      return response.data;
   
  }
);


const todosSlice = createSlice({
      name: 'todos',
      initialState: {
      todos: [],
      status: 'idle',
      error: null,
    },
    reducers: {},
    extraReducers: (builder) => {
      builder
        .addCase(fetchTodos.pending, (state) => {
          state.status = 'loading';
        })
        .addCase(fetchTodos.fulfilled, (state, action) => {
          state.status = 'succeeded';
          state.todos = action.payload;
        })
        .addCase(fetchTodos.rejected, (state, action) => {
          state.status = 'failed';
          state.error = action.error.message;
        })
        .addCase(updateTodoAsync.pending, (state) => {
          state.status = 'loading';
        })
        .addCase(updateTodoAsync.fulfilled, (state, action) => {
          state.status = 'succeeded';
          // Update the corresponding todo item in the state
          state.todos = state.todos.map((todo) =>
            todo.id === action.payload.id ? action.payload : todo
          );
        })
        .addCase(updateTodoAsync.rejected, (state, action) => {
          state.status = 'failed';
          state.error = action.error.message;
        });
    },
  });
  
  export default todosSlice.reducer;