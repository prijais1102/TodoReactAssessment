// src/components/EditModal.js

import React, { useState } from 'react';
import Modal from 'react-modal';
import axios from 'axios';
import './EditModal.css';

const EditModal = ({ isOpen, onRequestClose, onSave, initialTitle, initialDescription,taskId }) => {
    const [editedTitle, setEditedTitle] = useState(initialTitle);
  const [editedDescription, setEditedDescription] = useState(initialDescription);


  const handleSave = async () => {
    try {
      // Update the task on the JSON server
      await axios.put(`http://localhost:3000/tasks/${taskId}`, {
        title: editedTitle,
        description:editedDescription
      });

     
      onSave(taskId, editedTitle, editedDescription);
      setEditedTitle('');
      setEditedDescription('');
    } catch (error) {
      console.error('Error updating task:', error);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onRequestClose={onRequestClose}
      contentLabel="Edit Task"
      ariaHideApp={false}
      className="edit-modal" 
    >
      <h2>Edit Task</h2>
      <label>Title:</label>
      <input
        type="text"
        value={editedTitle}
        onChange={(e) => setEditedTitle(e.target.value)}
      />
       <label>Description:</label>
      <input
        type="text"
        value={editedDescription}
        onChange={(e) => setEditedDescription(e.target.value)}
      />
      <button onClick={handleSave}>Save</button> &nbsp;
      <button onClick={onRequestClose}>Cancel</button>
    </Modal>
  );
};

export default EditModal;
