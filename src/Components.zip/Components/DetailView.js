// src/components/DetailView.js

import React from 'react';
import Modal from 'react-modal';
import './DetailView.css'; 
const DetailView = ({ isOpen, onRequestClose, todo }) => {
  return (
    <Modal
      isOpen={isOpen}
      onRequestClose={onRequestClose}
      contentLabel="Todo Details"
      ariaHideApp={false}
      className="detail-modal">
      <h2>Todo Details</h2>
      <p><strong>Title:</strong> {todo.title}</p>
      <p><strong>Description:</strong> {todo.description}</p>
      <button onClick={onRequestClose}>Close</button>
    </Modal>
  );
};

export default DetailView;
